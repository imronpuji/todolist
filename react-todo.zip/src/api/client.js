import axios from "axios";
export default axios.create({
  baseURL: "https://virtserver.swaggerhub.com/hanabyan/todo/1.0.0",
  headers: {
    "Content-type": "application/json"
  }
});
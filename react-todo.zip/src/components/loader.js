function Loader(){
	return (
			<h3 className="m-4">Loading...</h3>
		)
}

export default Loader
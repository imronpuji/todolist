function Error(){
	return (
			<h3 className="m-4">Ups sorry there is a problem, wait a moment...</h3>
		)
}

export default Error